import { Button, Typography } from '@mui/material'
import React, { useState } from 'react'

const StateBasis = () => {
    //var fname = 'ajmal'
    var[fname,setfname]=useState("deepak is a")
    const changename = ()=>{
        console.log("clicked")
        setfname("thorappan")
    }
  return (
    <div style={{paddingTop:"80px"}}>
<Typography variant='h4'>{fname}</Typography>
<Button variant='contained'onClick={changename}>change</Button>
    </div>
  )
}

export default StateBasis