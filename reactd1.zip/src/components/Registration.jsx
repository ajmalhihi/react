import { TextField } from '@mui/material'
import React from 'react'

const Registration = () => {
  return (
    <div>
        <Registration/>
        <h1>Registration</h1>
        
        
    </div>
  )
}

export default Registration