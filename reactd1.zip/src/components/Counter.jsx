import React, { useState } from 'react'

const Counter = () => {
    var[count,setcount] = useState
  return (
    <div>Counter</div>
  )
}

export default Counter