import React from 'react'

const Mapping = () => {
  return (
    <div>  <style>={{paddingTop:"80px"}}
    

        
    </div>
  )
}

export default Mapping