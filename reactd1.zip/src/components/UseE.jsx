import { Button, Typography } from '@mui/material'
import React, { useState } from 'react'

const UseE = () => {
    var [name,setname] = useState() 
    const changename  = 
  return (
    <div> style={{paddingTop:"80px"}}
    <Button variant='contained' color='primary' onClick={}>home</Button>&nbsp;
    <Button variant='contained' color='secondary' onClick={}>gallery</Button>
  <Button variant='contained' color='error'onClick={}>contact</Button>
  <Typography>welcome to {name}</Typography>  


    </div>
  )
}

export default UseE