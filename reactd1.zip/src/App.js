import logo from './logo.svg';
import './App.css';
import Registration from './components/Registration';
import Appbar from './components/Appbar';
import StateBasis from './components/StateBasis';
import Counter from './components/Counter';
import UseE from './components/UseE';


function App() {
  return (
    <div className="App">
    {/* <Registration/> */}
  {/* <Appbar/>
  <StateBasis/> */}
  {/* <Counter/> */}
  <UseE/>
  );
}

export default App;
